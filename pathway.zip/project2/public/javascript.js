$('.que1').on('change', function() {
$('.que1').not(this).prop('checked', false);
 });
$('.que2').on('change', function() {
$('.que2').not(this).prop('checked', false);
});
$('.que3').on('change', function() {
$('.que3').not(this).prop('checked', false);
});
$('.que4').on('change', function() {
$('.que4').not(this).prop('checked', false);
});
$('.que5').on('change', function() {
$('.que5').not(this).prop('checked', false);
});
